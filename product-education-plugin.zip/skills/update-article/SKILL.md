---
name: update-article
description: >
  Update an existing Fresha Help Center article based on product changes, outputting a revised Word
  document (.docx). Use this skill when the user wants to update an article, revise existing content,
  apply product changes to an article, refresh documentation after a feature change, or edit an
  article to reflect new functionality. Trigger on phrases like "update this article", "revise this
  article", "the feature changed, update the article", "apply these changes to the article",
  "article needs updating", "refresh this content", or any request to modify an existing Help Center
  article based on product or feature changes.
---

# Update an Existing Help Center Article

Revise an existing Fresha Help Center article to reflect product changes, maintaining all writing standards and outputting the updated article as a Word document (.docx).

This skill supports **rich multi-source inputs** to ensure updates are accurate. The best updates come from combining the existing article with a discovery doc for context, Figma designs for new UI flows, and staging access to verify real behavior.

---

## Phase 1: Gather Inputs

Determine what sources are available for this update. The existing article is always required. Use AskUserQuestion to ask the user which additional inputs they can provide:

**Required:**
- **Existing article** — The current article as a .docx file, pasted text, or a link to the published Help Center page.

**Additional inputs (select all that apply):**
1. **Notion discovery doc** — A link to the PM's discovery document in Notion covering the feature changes.
2. **Figma design file** — A Figma link with updated design flows and UI screens.
3. **Staging environment URL** — A URL to the updated feature in staging, so Claude can verify real UI behavior.
4. **Change description / spec / release notes** — A text description, pasted spec, or uploaded file describing what changed.

If the user already provided inputs in their initial message, acknowledge those and only ask about additional inputs they haven't mentioned.

---

## Phase 2: Gather Context from Each Source

### 2A. Read the Existing Article

If a .docx file is provided, extract and read its content. If pasted text, work with that directly. Understand:
- Current article structure, sections, and steps
- Current terminology and UI element names
- Current screenshots and cross-references
- Current FAQs

### 2B. Notion Discovery Doc (if provided)

Fetch the Notion page using the Notion MCP tools (`notion-fetch`). The discovery doc follows a 5-section structure. Extract what's relevant to the update:

- **Feature changes** — What's new or different (Section 1: Overview, Section 4: Proposition)
- **Updated user stories** — New or modified workflows (Section 4.1: Recommended Features & User Stories)
- **Design direction changes** — New UX patterns, UI changes (Section 4.2: Design Direction)
- **New partner pain points** — Any new user feedback that should update FAQs (Section 3: User Feedback)

### 2C. Figma Design File (if provided)

Use the Figma MCP tools (`get_design_context`) to understand the updated design, then use browser automation to capture screenshots:

1. Call `get_design_context` with the Figma file key and node ID.
2. Open the Figma file in the browser.
3. Identify frames showing updated or new UI states.
4. Capture screenshots of each relevant frame.
5. Save with descriptive kebab-case filenames.
6. Record which screenshots replace existing article screenshots and which are new additions.

### 2D. Staging Environment (if provided)

Navigate the staging environment to verify the updated UI:

1. Open the staging URL in the browser.
2. **Log in using the credentials in `${CLAUDE_SKILL_ROOT}/references/staging-credentials.md`.** Read that file first, then use browser automation to enter the credentials and complete login. If a staging URL was provided by the user, navigate to that URL; otherwise use the default staging URL from the credentials file.
3. Navigate to the updated feature:
   - Walk through the updated workflows
   - Note any UI label changes, new buttons, moved elements
   - Capture screenshots at each key step
4. **Cross-reference with the existing article** — Identify where the current article's steps, terminology, or screenshots no longer match staging.

**Critical:** Staging UI labels are the ground truth. If a button was renamed, a menu moved, or terminology changed, the article must reflect the staging reality.

### 2E. Change Description / Spec / Release Notes (if provided)

Read the provided text or file. Extract:
- What specifically changed
- New features or workflows added
- Removed features or deprecated workflows
- UI changes (renamed elements, moved navigation, new screens)

---

---

## Phase 3: Apply the Updates

### Writing Standards (Apply Throughout)

#### Tone & Voice
Write in a clear, professional, and supportive tone. Be concise — every word must earn its place. Stay positive and action-oriented. Be conversational but informative. Use American English throughout (exception: "cancellation" keeps British spelling). Use contractions where natural. Never use passive voice. Present tense throughout.

#### Article Structure
Every article follows this structure:

1. **Title** — Action-oriented, concise, descriptive. Sentence case.
2. **Description** — Maximum 92 characters including spaces.
3. **Intro** — Starts with "Learn how to..." Maximum 2 sentences. First feature mention links to platform landing page.
4. **Headers (H2)** — Action-led, short, sentence case.
5. **Index sentence** — Only when multiple ways to accomplish one thing.
6. **"How it works" overview** — For complex features only, before steps.
7. **Steps** — Three-part formula: directional phrase + clear action + expected outcome.
8. **Callouts** — Notes only (never tips). Max one per flow. Positive sentiment.
9. **FAQs** — First person from partner perspective. Full context. Keywords and links.

#### Step Rules
- First step includes full navigation and platform link
- UI elements bolded and capitalized exactly as in-platform. **If staging was explored, use the exact labels observed in staging.**
- Numbered main steps; bullet points for sub-options
- Happy path first; advanced steps separate
- Desktop/mobile variants separated

#### Style Rules
- "Click" (desktop) / "Tap" (mobile) — never "Press"
- "For example" not "e.g."
- Full sentences, no vague instructions
- Examples relevant to beauty/wellness
- **Never include pricing information**

### Required References

Before updating, read these files from `${CLAUDE_SKILL_ROOT}/references/`:

1. **`glossary.md`** — REQUIRED. Use the exact official names for every UI component. Check desktop vs. mobile terminology.
2. **`fresha-platform-overview.md`** — REQUIRED. Understand where the feature fits in the broader platform.
3. **`writing-guide.md`** — Full writing guide for detailed rule references.
4. **`checklist.md`** — For the final verification pass.
5. **`example-payment-policies.md`** and **`example-loyalty-points.md`** — Study these to understand how standards look in practice.

### Update Process

1. **Load references.** Read the glossary, platform overview, writing guide, and both example articles. The glossary and platform overview are critical — never skip them.

2. **Apply the updates.** Make all changes while maintaining:
   - Consistent tone and voice throughout
   - Proper formatting (bold UI elements, numbered steps, etc.)
   - Correct article structure per the writing standards
   - Updated screenshot references where the UI has changed
   - Updated hyperlink references if related features changed
   - **Staging-verified UI labels** as the ground truth for all element names

3. **Update screenshots.** Replace outdated screenshot references with new captures:
   - If real screenshots were captured: `[Screenshot: filename.png — description of what it shows]`
   - If screenshots need recapturing: `[Screenshot: description of what to capture — UPDATED]`

4. **Update FAQs.** Revise FAQs to reflect what's changed. Draw from multiple sources: how the feature works now, edge cases or exceptions in the discovery doc, design decisions partners are likely to question, and any relevant user feedback — but treat user feedback as one signal among many, not the sole source. User feedback may reflect old pain with the pre-existing experience; FAQs should address the updated feature as it stands.

5. **Generate the updated Word document.** Read the docx skill and create the updated .docx. If the original was provided as a .docx, preserve as much of the original formatting as practical.

6. **Save the file** to the user's workspace folder. Use the original filename with `-updated` appended if keeping both versions, or the same filename if replacing.

7. **Run a checklist review.** Read `${CLAUDE_SKILL_ROOT}/references/checklist.md` and verify the updated article still meets every criterion. Flag any areas that need attention due to the changes.

8. **Summarize changes.** Provide a clear summary of what was changed, added, or removed, and highlight any items needing manual attention (new screenshots, links to verify, etc.).
