# Fresha Help Center — Complete Article Writing Guide

This is the exhaustive reference for writing Fresha Help Center articles. It covers every rule, convention, and formatting standard the product content team follows.

---

## 1. Tone & Voice

### Core Principles
- **Clear**: Easy to understand on the first read
- **Professional**: Authoritative but not stiff
- **Supportive**: Helpful, encouraging, solution-focused
- **Concise**: Every word earns its place — cut anything unnecessary
- **Positive**: Focus on what users *can* do, not what they can't
- **Action-oriented**: Lead with actions and outcomes
- **Conversational but informative**: Friendly without being casual

### Language Rules
- American English throughout (exception: "cancellation" retains British spelling)
- Use contractions where natural ("you'll", "don't", "it's")
- Never use passive voice ("Click **Save**" not "The **Save** button should be clicked")
- Present tense throughout ("Click" not "You will need to click")
- Full sentences, even for short instructions
- "Click" consistently — never "Press", "Tap", or "Hit" for desktop actions
- "For example" written out in article body — never "e.g."
- Examples must be relevant to beauty and wellness businesses

---

## 2. Article Structure

### Title
- Action-oriented, concise, and descriptive
- Sentence case (capitalize first word and proper nouns only)
- Never redundant with category or sub-category names
- Good: "Set up online booking for your salon"
- Bad: "Online Booking - Setting Up Online Booking"

### Description
- Maximum 92 characters including spaces
- Summarizes what the reader will learn
- Appears in search results and article previews

### Intro
- Always starts with "Learn how to..."
- Maximum 2 sentences
- First mention of the feature links to the platform landing page
- Briefly explains what the article covers and why it matters

### Headers (H2)
- Action-led and short
- Sentence case
- Each header introduces a distinct task or workflow
- Good: "Add a new service"
- Bad: "Adding New Services to Your Menu"

### Index Sentence
- Include ONLY when there are multiple ways to accomplish one thing
- Format: "From [location], you can:"
- Follow with a list of actions as hyperlinks jumping to the relevant sections
- Omit when an article covers a single linear workflow

### "How it works" Overview
- Include for complex features only
- Place before step-by-step instructions
- Explain the feature's purpose and behavior in plain language
- Help the reader understand *why* before learning *how*

### Steps
Each step follows a three-part formula:

1. **Directional phrase** — where to navigate
2. **Clear action** — what to do
3. **Expected outcome** — what happens as a result

#### Step Rules
- Number all main steps sequentially
- Use bullet points for sub-options or choices within a step
- First step always includes the full navigation path (e.g., "From the main menu on the left, go to **Calendar**")
- First step links to the platform landing page
- **Bold** and capitalize UI elements exactly as they appear in the platform (buttons, tabs, toggles, field names)
- Include screenshot placeholders where visuals would help comprehension
- Hyperlink to relevant articles when referencing other Fresha features
- Happy path first — put the main, most common workflow before edge cases
- Advanced steps go in separate sections after the happy path

#### Step Examples
Good:
> 1. From the main menu on the left, go to [**Calendar**](link). The calendar view opens.
> 2. Click **+ New appointment**. The new appointment panel appears on the right.
> 3. Search for and select the client. Their details populate automatically.

Bad:
> 1. Go to your calendar
> 2. You will need to click on the new appointment button
> 3. Find the client you want

### Callouts
- Notes only — never label them as "tips"
- Maximum one callout per flow/section
- Positive sentiment — frame as helpful information, not warnings
- Format: `> **Note:** [content]`

### FAQs
- Written in first person from the partner's perspective ("How do I cancel an appointment?")
- Answers must include full context — don't assume the reader has read the article
- Include search keywords naturally in questions and answers
- Link to relevant articles within answers
- Cover genuine questions partners actually ask
- Never repeat content already covered in the article body

---

## 3. Formatting Standards

### Bold
- UI elements: buttons, tabs, toggles, menu items, field labels
- Capitalize exactly as they appear in the Fresha platform
- Example: Click **Save changes** (if the button says "Save changes" in the platform)

### Hyperlinks
- Link to related Help Center articles whenever referencing another Fresha feature
- First step links to the platform landing page
- Use descriptive link text (not "click here")

### Screenshots
- Place within the step where the action is being described
- Capture only the relevant portion of the UI
- Should show the state the user will see at that point in the workflow
- Add a brief description or annotation if the screenshot alone isn't clear

### Lists
- Numbered lists for sequential steps
- Bullet points for non-sequential options or choices
- Never mix numbered and bulleted items in the same list level

---

## 4. Content Principles

### Clarity First
- No vague instructions — always give specific direction
- Bad: "Go to settings and find the option"
- Good: "From the main menu, go to **Settings** > **Online booking**. Click the **Booking rules** tab."

### Consistency
- Same terminology throughout every article
- Same formatting patterns
- Same navigation descriptions ("From the main menu on the left" — not sometimes "sidebar" and sometimes "navigation")

### Search Optimization
- Include relevant search keywords naturally in titles, descriptions, and content
- Anticipate what terms partners might search for
- Use the same terminology partners use (not internal product jargon)

---

## 5. Word Document Output

When generating articles as Word documents:
- Use Heading 1 for the article title
- Use Heading 2 for section headers
- Bold all UI element references
- Number steps using ordered lists
- Use bullet points for sub-options
- Include placeholder text like `[Screenshot: description of what to capture]` where screenshots should go
- Include hyperlink placeholders like `[Link: Article Name]` where cross-references are needed
- Add the description at the top, clearly labeled
- Add FAQs at the end, clearly sectioned
