# Content Guideline Checklist

Use this checklist to review any Help Center article for compliance with Fresha writing standards.

---

## Tone & Voice

- [ ] Clear, professional, and supportive tone
- [ ] Concise — every word is necessary
- [ ] Positive and action-oriented (focus on what users *can* do)
- [ ] Conversational but informative

---

## Structure

- [ ] Title is action-oriented, concise, and descriptive
- [ ] Intro starts with "Learn how to" (2 sentences max)
- [ ] Description is 92 characters or fewer including spaces
- [ ] Headers are H2, action-led, and short
- [ ] Happy path comes first; advanced steps follow in separate sections
- [ ] Index sentence included only when there are multiple ways to do one thing
- [ ] "How it works" overview included for complex features

---

## Steps

- [ ] Each step includes a directional phrase, clear action, and expected outcome
- [ ] First step always includes full navigation (e.g., "From the main menu on the left, go to **Calendar**")
- [ ] Buttons, tabs, and feature names are **bolded** and capitalized as they appear in-platform
- [ ] Present tense used throughout (e.g., "Click" not "You will need to click")
- [ ] Steps are numbered; sub-options use bullet points
- [ ] Screenshots included within steps where helpful
- [ ] Hyperlinks to relevant articles where other features are referenced
- [ ] First step links to the platform landing page

---

## Style & Grammar

- [ ] American English (except "cancellation")
- [ ] Contractions used where natural
- [ ] No passive voice
- [ ] Full sentences, even for short instructions
- [ ] Sentence case for all headings
- [ ] "For example" written out (not "e.g.") in article body
- [ ] Examples are relevant to beauty and wellness businesses

---

## Callouts & FAQs

- [ ] Callouts are notes only (no tips), max one per flow, positive sentiment
- [ ] FAQs are written in first person from the partner's perspective
- [ ] FAQ answers include full context (don't assume the article was read)
- [ ] FAQs include keywords and link to relevant articles
- [ ] FAQs cover genuine partner questions — no repetition of article content

---

## UI Terminology (Glossary)

- [ ] All UI component names match the official glossary (e.g., "main menu" not "sidebar" or "navigation")
- [ ] Desktop navigation uses "From the main menu on the left of your screen"
- [ ] Mobile navigation uses "From the main menu at the bottom of your screen, tap on **More** (grid icon)"
- [ ] Desktop uses "click" / mobile uses "tap" — never mixed
- [ ] Actions menu on mobile includes "(three dots)" descriptor
- [ ] Save button location matches platform: "top right" on desktop, "at the bottom" on mobile
- [ ] Section names capitalized and bolded exactly as they appear in the platform (e.g., **Online bookings**, **Add-ons**)
- [ ] UI containers use correct names: "panel" (side panel), "view" (full-screen overlay), "pop-up" (small overlay)

---

## Pricing

- [ ] No dollar amounts, subscription costs, or per-unit rates anywhere in the article
- [ ] No trial details (duration, included minutes/units, etc.)
- [ ] Pricing references use generic language only (e.g., "paid add-on", "additional charges may apply") or link to a pricing page

---

## General

- [ ] No vague instructions (always give direction)
- [ ] No redundant titles (don't repeat category/sub-category info)
- [ ] Consistent phrasing throughout (e.g., always "Click," never "Press")
- [ ] Relevant search keywords included
