# Fresha UI Glossary

> **Purpose:** This glossary defines the official external names for all Fresha platform UI components. When writing Help Center articles, **always** use these exact names. Bold and capitalize UI element names exactly as they appear here. This ensures consistency across all articles and matches what partners see in the product.

---

## Navigation — Desktop

### Main Menu
The vertical sidebar on the left side of the screen containing the primary navigation.

- **External name:** "main menu"
- **Usage:** "From the main menu on the left of your screen, go to **[Section]**."

### Main Menu Navigation Items
The clickable items within the main menu. Always bold and capitalize as listed:

- **Home**
- **Calendar**
- **Sales**
- **Clients**
- **Catalog**
- **Online bookings**
- **Marketing**
- **Team**
- **Reports**
- **Add-ons**
- **Settings**

### Left Menu Panel
The secondary navigation panel that appears within a section (e.g., inside Clients, Settings, Catalog).

- **External name:** "left menu panel"
- **Usage:** "In the left menu panel, select **[item]**."

### List (Category/Items List)
A list of items within a section, such as services, products, or team members.

- **External name:** "[Name] list" — use the specific name (e.g., "Services list", "Products list", "Team members list")
- **Usage:** "From the **Services list**, click on **[service name]**."

### Toolbar
The horizontal bar at the top right of the screen containing icons and actions.

- **External name:** "toolbar"
- **Usage:** "From the toolbar on the top right of your screen..."

### Toolbar Icons
Individual icons within the toolbar. Always refer to them by their function:

- **Profile picture** — the user's avatar
- **Search icon** — magnifying glass
- **News icon** — megaphone/newspaper icon
- **Notifications icon** — bell icon
- **Wallet icon** — wallet icon

---

## Navigation — Mobile

### Main Menu (Mobile)
The bottom navigation bar on mobile devices.

- **External name:** "main menu at the bottom of your screen"
- **Usage:** "From the main menu at the bottom of your screen, tap on **More** (grid icon) and open **[Section]**."

### More Menu (Mobile)
The grid icon that opens additional navigation options on mobile.

- **External name:** "**More** (grid icon)"
- **Usage:** "Tap on **More** (grid icon) and open **[Section]**."

### Actions — Mobile
The three-dot menu on mobile.

- **External name:** "**Actions** (three dots)"
- **Usage:** "Tap on **Actions** (three dots) next to **[item]** and select **[option]**."

---

## Common UI Elements

### Panel
A side panel that slides in from the right when clicking on an item or action. Used for editing, viewing details, or selecting options.

- **External name:** "panel"
- **Usage:** "...and select **Edit** from the panel."

### View
A full-screen or near-full-screen overlay that opens when accessing detailed content (e.g., an appointment, a client profile, a sale).

- **External name:** "[Name] view" — use the specific context (e.g., "appointment view", "service view", "team member view")
- **Usage:** "In the **Edit points earned** view, specify the number of points..."

### Button
A clickable element that performs an action. Always bold the button label exactly as it appears in the platform.

- **Primary button:** The main action button (e.g., **Save**, **Enable**, **Add**, **Apply**)
- **Secondary button:** A secondary action (e.g., **Cancel**, **Back**, **Discard**)
- **Usage:** "Click on the **Save** button in the top right to update your changes."
- **Mobile usage:** "Tap on the **Save** button at the bottom to confirm."

### Actions (Three Dots)
The three-dot icon button that opens a menu of available actions for an item.

- **External name (Desktop):** "**Actions**"
- **External name (Mobile):** "**Actions** (three dots)"
- **Usage (Desktop):** "Click on **Actions** next to **[item]**, and select **Edit** from the panel."
- **Usage (Mobile):** "Tap on **Actions** (three dots) next to **[item]** and select **Edit** from the options."

### Toggle
A switch control that enables or disables a feature or setting.

- **External name:** "toggle"
- **Usage:** "Use the toggle next to **[setting name]** to enable or disable **[feature]**."

### Dropdown
A selector that opens a list of options when clicked.

- **External name:** "dropdown"
- **Usage:** "Use the dropdown to select **[option]**."
- **Also acceptable:** "Select **[option]** from the drop-down menu."

### Checkbox
A square box that can be ticked or unticked.

- **External name:** "checkbox"
- **Usage:** "Tick the checkbox next to **[option]** to enable **[feature]**."

### Radio Button
A circular selector for choosing one option from a group.

- **External name:** "radio button"
- **Usage:** "Select the **[option]** radio button."

### Text Field
An input area where users type text or numbers.

- **External name:** "text field"
- **Usage:** "Enter the amount in the **[field name]** text field."

### Search Bar
A text input used specifically for searching.

- **External name:** "search bar"
- **Usage:** "Use the search bar to find **[item]**."

### Tabs
Horizontal navigation elements that switch between views within the same page or section.

- **External name:** "tabs"
- **Usage:** "Select the **[tab name]** tab to view **[content]**."

### Filters
Controls that narrow down the displayed items based on criteria.

- **External name:** "Filters"
- **Usage:** "Click on **Filters** to narrow down results by **[criteria]**."

### Pop-up
A small overlay that appears on top of the current view, typically for confirmations or brief inputs.

- **External name:** "pop-up"
- **Usage:** "Click on the **Disable** button in the pop-up to confirm."

### Info Banner
A colored banner displayed at the top of a section or page to provide contextual information or alerts.

- **External name:** "info banner"
- **Usage:** Refer to the content of the banner rather than the element itself where possible.

### Status Labels
Colored labels or badges indicating the status of an item (e.g., Confirmed, Completed, Cancelled, No-show).

- **External name:** Use the specific status name in bold (e.g., "**Confirmed**", "**Completed**")

### Breadcrumb
A navigation trail showing the current location within the platform hierarchy.

- **External name:** "breadcrumb"
- **Usage:** Rarely referenced directly in articles — use navigation steps instead.

### Tooltip
A small text box that appears when hovering over an element.

- **External name:** "tooltip"
- **Usage:** Rarely referenced directly — describe the information shown instead.

### Custom Order
A drag-and-drop control for reordering items in a list.

- **External name:** "Custom order"
- **Usage:** "Click **Custom order** to rearrange **[items]** in your preferred order."

---

## Calendar & Scheduling

### Calendar
The main scheduling view.

- **External name:** "calendar"
- **Usage:** "From the main menu on the left of your screen, go to **Calendar**."

### Calendar Toolbar
The toolbar within the calendar view for changing dates, views, and filters.

- **External name:** "calendar toolbar"

### Calendar Views
The different display modes for the calendar.

- **Day view** / **Week view** / **Month view**
- **Usage:** "Switch to **Week view** from the calendar toolbar."

### Date Selector
The controls for navigating between dates in the calendar.

- **External name:** "date selector"

### Appointment
An individual booking shown as a card on the calendar.

- **External name:** "appointment"

### Appointment View
The detail view that opens when clicking on an appointment.

- **External name:** "appointment view"

### New Appointment
The view for creating a new appointment.

- **External name:** "New appointment"

### Blocked Time
A time slot blocked off on the calendar (e.g., breaks, personal time).

- **External name:** "blocked time"

### Blocked Time View
The detail view for a blocked time slot.

- **External name:** "blocked time view"

### Waitlist
The list of clients waiting for an available appointment slot.

- **External name:** "Waitlist"

### Waitlist Icon
The icon representing the waitlist in the calendar toolbar.

- **External name:** "Waitlist icon"

---

## Sales & Checkout

### Checkout
The process and view for completing a payment for an appointment or sale.

- **External name:** "checkout"

### Quick Sale
A sale made without an associated appointment.

- **External name:** "quick sale"

### Sale
A completed transaction.

- **External name:** "sale"

### Sale View
The detail view of a completed sale.

- **External name:** "sale view"

### Daily Sales
The list of all sales for a given day.

- **External name:** "daily sales"

---

## Client Management

### Client List
The full list of clients.

- **External name:** "client list" or "Clients list"
- **Usage:** "From the main menu on the left of your screen, go to **Clients**."

### Client
A single client record in the list.

- **External name:** "client"

### Client Profile
The full detail view of a client.

- **External name:** "client profile"

### Client Details
The overview/details section within a client's profile.

- **External name:** "client details"

### Client Profile Tabs
Tabs within a client profile for viewing different information:

- **Appointments** — past and upcoming appointments
- **Sales** — purchase history
- **Products** — product purchase history
- **Reviews** — reviews left by the client
- **Forms** — client forms
- **Files** — uploaded client files

### Client Loyalty
The loyalty program section within Clients.

- **External name:** "Client loyalty"

### Loyalty Points
The points-based loyalty system.

- **External name:** "Loyalty points"

### Loyalty Tiers
The tier-based loyalty system.

- **External name:** "Loyalty tiers"

### Rewards
Rewards that clients can claim with loyalty points.

- **External name:** "rewards"

### Import / Export Clients
Tools for bulk importing or exporting client data.

- **External name:** "Import clients" / "Export clients"

---

## Team Management

### Team Members List
The list of all team members.

- **External name:** "Team members list"

### Team Member
A single team member record.

- **External name:** "team member"

### Team Member View / Profile
The detail view of a team member.

- **External name:** "team member view" or "team member profile"

### Team Member Profile Tabs
Tabs within a team member's profile:

- **Details** — personal and contact details
- **Services** — assigned services
- **Schedule** — working hours and time off
- **Commission** — commission settings
- **Timesheets** — clock-in/clock-out records
- **Pay runs** — payment history

### Commission Profile
The commission settings for a team member.

- **External name:** "commission profile"

### Working Hours
The scheduled working hours for a team member.

- **External name:** "working hours"

### Time Off
Scheduled time off for a team member.

- **External name:** "time off"

### Scheduled Shifts
Shift schedule for a team member.

- **External name:** "Scheduled shifts"

### Shift
An individual work shift.

- **External name:** "shift"

### Timesheets
Clock-in/clock-out records for team members.

- **External name:** "Timesheets"

### Pay Runs
Payment records for team members.

- **External name:** "Pay runs"

---

## Catalog

### Services List
The list of all services offered.

- **External name:** "services list"
- **Usage:** "From the **Catalog**, open the **services list**."

### Service Category
A grouping of related services.

- **External name:** "service category"

### Service
An individual service offered to clients.

- **External name:** "service"

### Service View
The detail/edit view for a service.

- **External name:** "service view"

### Products List
The list of all retail products.

- **External name:** "products list"

### Product
An individual retail product.

- **External name:** "product"

### Product View
The detail/edit view for a product.

- **External name:** "product view"

### Memberships
Recurring membership packages.

- **External name:** "memberships"

### Membership
A single membership record.

- **External name:** "membership"

### Gift Cards
Purchasable gift cards.

- **External name:** "gift cards"

---

## Online Bookings & Marketing

### Online Bookings
The settings area for managing online booking configuration.

- **External name:** "Online bookings"

### Booking Links
Links for sharing online booking pages.

- **External name:** "booking links"

### Booking Widget
The embeddable booking widget for websites.

- **External name:** "booking widget"

### Marketing
The main marketing section.

- **External name:** "Marketing"

### Campaigns
Marketing campaign management.

- **External name:** "campaigns"

### Automated Messages
Pre-configured messages sent automatically based on triggers.

- **External name:** "automated messages"

### Blast Campaigns
One-time marketing messages sent to a group of clients.

- **External name:** "blast campaigns"

### Smart Pricing
Dynamic pricing features for services.

- **External name:** "smart pricing"

---

## Reports

### Reports
The reports section for business analytics.

- **External name:** "Reports"

### Report View
The detail view of an individual report.

- **External name:** "report view"

---

## Settings

### Settings
The main settings area.

- **External name:** "Settings"
- **Usage (Desktop):** "From the main menu on the left of your screen, go to **Settings**."
- **Usage (Mobile):** "From the main menu at the bottom of your screen, tap on **More** (grid icon) and open **Settings**."

### Workspace Settings
The settings list within Settings on mobile.

- **External name:** "Workspace settings"
- **Usage (Mobile):** "Under the **Workspace settings** list, tap on **[section]**."

### Business Details
Business profile and information settings.

- **External name:** "business details"

### Payments (Settings)
Payment configuration settings.

- **External name:** "Payments"
- **Usage:** "Click on the **Payments** category to manage your payment policy."

### Payment Policy
The payment policy configuration area.

- **External name:** "payment policy"

### Tax Settings
Tax configuration area.

- **External name:** "tax settings"

### Notifications Settings
Notification preferences and configuration.

- **External name:** "notifications settings"

---

## Billing

### Billing
The billing and subscription management area.

- **External name:** "Billing"

### Subscription
The current subscription plan details.

- **External name:** "subscription"

### Invoice
A billing invoice.

- **External name:** "invoice"

---

## Help

### Help
The help and support access point.

- **External name:** "Help"

---

## Desktop vs. Mobile Terminology

When writing steps, use the correct verb and description for each platform:

| Action | Desktop | Mobile |
|--------|---------|--------|
| Interact with a UI element | "click" or "click on" | "tap" or "tap on" |
| Open main menu | "From the main menu on the left of your screen, go to **[Section]**" | "From the main menu at the bottom of your screen, tap on **More** (grid icon) and open **[Section]**" |
| Access actions menu | "click on **Actions** next to **[item]**" | "tap on **Actions** (three dots) next to **[item]**" |
| Save changes | "Click on the **Save** button in the top right" | "Tap on the **Save** button at the bottom" |
| Navigation description | "on the left of your screen" | "at the bottom of your screen" |

---

## Formatting Rules for UI Elements

1. **Always bold** UI element names when referencing them in steps: **Save**, **Enable**, **Actions**, **Client loyalty**
2. **Capitalize exactly** as the element appears in the platform — do not change capitalization
3. **Never abbreviate** UI element names
4. **Use the external name** from this glossary, not internal/technical names
5. When an element has an icon, include the icon description in parentheses on mobile: "**Actions** (three dots)", "**More** (grid icon)"
6. When referencing a section that contains a list, use the format: "**[Name] list**" (e.g., "the **Services list**")
