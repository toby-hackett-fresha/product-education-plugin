# Example Article: Set up and manage Client loyalty points

> **Why this is a good example:** This article covers a feature with multiple sub-workflows (different ways to earn points), each following the same structural pattern. It demonstrates how to handle repeating sections with consistent formatting, an index for navigation, desktop/mobile variants, and a "How it works" overview for a complex feature.

---

## Title

Set up and manage Client loyalty points

> **What works:** Action-oriented ("Set up and manage"), concise, descriptive. Sentence case. Clearly describes the scope of the article.

## Description

Enable points, set earning rules, and create rewards clients can claim with their points.

> **What works:** Under 92 characters. Lists the key actions covered. Action-oriented.

## Intro

In this guide, you'll learn how to set up a point-based loyalty program that allows clients to earn and spend points measured by their engagement with your business.

> **Note:** This intro doesn't follow the standard "Learn how to" opening. The preferred format would be: "Learn how to set up a point-based loyalty program that allows clients to earn and spend points based on their engagement with your business."

## In this article (Index)

- How Loyalty points work
- Enable loyalty points
- Edit ways to earn points
  - Make a purchase
  - Leave a review
  - Book online
  - Complete appointment
- Add Ways to earn points
- Manage loyalty point settings

> **What works:** Index is included because the article covers multiple distinct workflows. Sub-items are indented to show hierarchy. All items link to their sections.

---

## How Loyalty points work

Loyalty points reward clients for their engagement with your business. Clients earn points for various interactions and can [**exchange them for rewards that you create**](https://www.fresha.com/help-center/knowledge-base/clients/565-set-up-and-manage-client-loyalty-points), such as discounts and free items.

Once Client loyalty is enabled, ways to earn points are automatically set up by default and can be edited to fit your needs.

> **What works:** Brief "How it works" overview before the steps. Explains the feature's purpose. Cross-references the rewards article. Sets expectations for what comes next.

---

## Enable loyalty points

### Desktop

1. From the main menu on the left of your screen, go to [**Clients**](https://partners.fresha.com/clients/list?client-list).

2. In the left menu panel, select **Client loyalty** to view and manage your points settings.

3. Next to **Loyalty points**, click on the **Enable** button to allow clients to earn and spend points.

### Mobile

1. From the main menu at the bottom of your screen, tap on **More** (grid icon) and open [**Clients**](https://partners.fresha.com/clients/list?client-list).

2. Select **Client loyalty** to view and manage your points settings.

3. Under **Loyalty points**, tap on the **Enable** button to allow clients to earn and spend points.

Once enabled, clients will start earning points based on your master point settings and preset ways to earn points.

> **What works:** Short, focused setup section. First step includes full navigation with platform link. Each step has action + outcome. Closing sentence confirms what happens after completing the steps.

---

## Edit ways to earn points

You can set up various ways for clients to earn points based on their actions. Points can be earned when clients:

- **Make a purchase**: Clients earn points based on how much they spend.
- **Leave a review**: Earn points for leaving a review after the appointment.
- **Book online**: Clients receive points for completing appointments booked online.
- **Complete appointments**: Points are given for reaching a set number of completed appointments.

> **What works:** Brief overview before diving into each sub-section. Lists the options with bold labels and descriptions. Acts as an index sentence for the sub-workflows that follow.

---

## Make a purchase

### Desktop

1. Open [**Points**](https://partners.fresha.com/clients/loyalty/points) from **Client loyalty**.

2. Under **Ways to earn points**, click on **Actions** next to **Make a purchase**, and select **Edit** from the panel.

3. In the **Edit points earned** view, under **Earning type**, choose whether clients earn points based on the amount spent (**Incremental**) or a set number of points per purchase (**Fixed**).

4. Specify the number of points clients will receive for every dollar they spend.

5. Under **Earning limits**, tick the checkboxes next to each limit to set a minimum purchase amount or limit the number of times clients can earn points when making a purchase.

6. Click on the **Save** button in the top right to update the way to earn points.

### Mobile

1. Open [**Points**](https://partners.fresha.com/clients/loyalty/points) from **Client loyalty**.

2. Under **Ways to earn points**, tap on **Actions** (three dots) next to **Make a purchase** and select **Edit** from the options.

3. In the **Edit points earned** view, under **Earning type**, choose whether clients earn points based on the amount spent (**Incremental**) or a set number of points per purchase (**Fixed**).

4. Specify the number of points clients will receive for every dollar they spend.

5. Under **Earning limits**, tick the checkboxes next to each limit to set a minimum purchase amount or limit the number of times clients can earn points when making a purchase.

6. Tap on the **Save** button at the bottom to update the way to earn points.

Once updated, clients will earn points when making a purchase based on your new settings. You can update these settings at any time using the same steps.

---

## Leave a review

### Desktop

1. Open [**Points**](https://partners.fresha.com/clients/loyalty/points) from **Client loyalty**.

2. Under **Ways to earn points**, click on **Actions** next to **Leave a review**, and select **Edit** from the panel.

3. In the **Edit points earned** view, specify the number of points clients will earn for every review they leave.

4. Under **Earning limits**, tick the checkbox to limit the number of times clients can earn points for leaving a review.

5. Click on the **Save** button in the top right to update the way to earn points.

### Mobile

1. Open [**Points**](https://partners.fresha.com/clients/loyalty/points) from **Client loyalty**.

2. Under **Ways to earn points**, tap on **Actions** (three dots) next to **Leave a review**, and select **Edit** from the panel.

3. In the **Edit points earned** view, specify the number of points clients will earn for every review they leave.

4. Under **Earning limits**, tick the checkbox to limit the number of times clients can earn points for leaving a review.

5. Tap on the **Save** button at the bottom to update the way to earn points.

Once updated, clients will earn points when they leave a review based on your new settings. You can update these settings at any time using the same steps.

---

## Book online

### Desktop

1. Open [**Points**](https://partners.fresha.com/clients/loyalty/points) from **Client loyalty**.

2. Under **Ways to earn points**, click on **Actions** next to **Book online**, and select **Edit** from the panel.

3. In the **Edit points earned** view, specify the number of points clients will earn for every appointment booked online.

4. Under **Earning limits**, tick the checkboxes next to each limit to set a minimum appointment value or limit the number of times clients can earn points when booking online.

5. Click on the **Save** button in the top right to update the way to earn points.

### Mobile

1. Open [**Points**](https://partners.fresha.com/clients/loyalty/points) from **Client loyalty**.

2. Under **Ways to earn points**, tap on **Actions** (three dots) next to **Book online**, and select **Edit** from the panel.

3. In the **Edit points earned** view, specify the number of points clients will earn for every appointment booked online.

4. Under **Earning limits**, tick the checkboxes next to each limit to set a minimum appointment value or limit the number of times clients can earn points when booking online.

5. Tap on the **Save** button at the bottom to update the way to earn points.

Once updated, clients will earn points when they book online based on your new settings. You can update these settings at any time using the same steps.

---

## Complete appointment

### Desktop

1. Open [**Points**](https://partners.fresha.com/clients/loyalty/points) from **Client loyalty**.

2. Under **Ways to earn points**, click on **Actions** next to **Complete appointment**, and select **Edit** from the panel.

3. In the **Edit points earned** view, specify the number of points clients will earn for every appointment completed.

4. Under **Earning limits**, tick the checkboxes next to each limit to set a minimum appointment value or limit the number of times clients can earn points for completed appointments.

5. Click on the **Save** button in the top right to update the way to earn points.

### Mobile

1. Open [**Points**](https://partners.fresha.com/clients/loyalty/points) from **Client loyalty**.

2. Under **Ways to earn points**, tap on **Actions** (three dots) next to **Complete appointment**, and select **Edit** from the panel.

3. In the **Edit points earned** view, specify the number of points clients will earn for every appointment completed.

4. Under **Earning limits**, tick the checkboxes next to each limit to set a minimum appointment value or limit the number of times clients can earn points for completed appointments.

5. Tap on the **Save** button at the bottom to update the way to earn points.

Once updated, clients will earn points when they complete an appointment based on your new settings. You can update these settings at any time using the same steps.

> **Pattern note:** Each "way to earn" sub-section follows an identical structure: Desktop steps, Mobile steps, closing confirmation sentence. This consistency makes articles scannable and predictable for readers. When a feature has repeating sub-workflows, use this same pattern throughout.

---

## Add ways to earn points

### Desktop

1. Open [**Points**](https://partners.fresha.com/clients/loyalty/points) from **Client loyalty**.

2. Under **Ways to spend points**, click on the **Add reward** button to create a new way for clients to spend points.

3. In the **Choose reward type** step, select a reward type and follow the next steps to [**create a new client reward**](https://www.fresha.com/help-center/knowledge-base/clients/584-create-client-rewards).

### Mobile

1. Open [**Points**](https://partners.fresha.com/clients/loyalty/points) from **Client loyalty**.

2. Under **Ways to spend points**, tap on the **Add reward** button to create a new way for clients to spend points.

3. In the **Choose reward type** step, select a reward type and follow the next steps to [**create a new client reward**](https://www.fresha.com/help-center/knowledge-base/clients/584-create-client-rewards).

The new **way to spend points** will be immediately available for clients to claim using their points. To update or remove a reward, click **Actions** next to the item in the **Ways to spend points** list.

> **What works:** Cross-references the dedicated "create client rewards" article rather than duplicating those steps. Keeps this article focused.

---

## Manage loyalty point settings

### Desktop

1. Open [**Points**](https://partners.fresha.com/clients/loyalty/points) from **Client loyalty**.

2. Next to **Loyalty points**, click on the **Actions** button and select one of the following options from the panel:

    - **Edit**: Update the points expiry to either **12** or **24** months. Click on the **Save** button in the top right to confirm your changes. By default, unused points expire after 12 months.

    - **Disable**: Turn off Loyalty points. Clients will no longer earn or use their points to claim rewards. Click on the **Disable** button in the pop-up to confirm.

### Mobile

1. Open [**Points**](https://partners.fresha.com/clients/loyalty/points) from **Client loyalty**.

2. Next to **Loyalty points**, tap on **Actions** (three dots) and select one of the following options:

    - **Edit**: Update the points expiry to either **12** or **24** months. Tap on the **Save** button at the bottom to confirm your changes. By default, unused points expire after 12 months.

    - **Disable**: Turn off Loyalty points. Clients will no longer earn points or use their points to claim rewards. Tap the **Disable** button in the pop-up to confirm.

Once you have updated expiry settings for Loyalty points, the changes will only apply to points earned from that date onward. Points earned before the update will still follow the original expiration rules.

If you disable Loyalty points, any existing points will stay in your clients' accounts but can't be used until you re-enable it.

> **What works:** Uses bullet points for non-sequential options (Edit vs. Disable) within a numbered step. Each option includes the action and its outcome. Closing paragraphs explain important consequences — key information partners need to know.

---

## FAQs

### Can I set different point values for different services?

Yes, you can customize point values for different services by creating multiple, specific rewards. When setting up Loyalty points, you'll choose which services, products, memberships, or gift cards are eligible for redemption. To apply different point values to different services, you'll need to create separate rewards for each one, assigning unique points requirements for redemption of each reward.

### Will clients be notified when they earn points?

Yes, clients automatically receive a summary email with their earned points, balance, and upcoming expiries. When clients reach a new tier, they receive an immediate notification about the rewards they've unlocked. These notifications are enabled by default, but you can customize them anytime in [**your Automated messages settings**](https://www.fresha.com/help-center/knowledge-base/marketing/572-manage-automated-messages-for-client-loyalty).

### Where can clients track their points?

Clients can view their points balance and progress in their Fresha Wallet, under the Loyalty rewards section of their account. Learn more about [**how clients keep up with their loyalty progress and rewards**](https://www.fresha.com/help-center/knowledge-base/clients/571-understand-how-clients-engage-with-your-loyalty-program).

### Can I set different expiry rules for different clients?

Point expiry settings apply to all clients equally, including the expiry date.

### Can I manually restore expired points for a client?

Once points have expired, you cannot manually reinstate them. However, you can [**manually add new Loyalty points**](https://www.fresha.com/help-center/knowledge-base/clients/580-manage-a-client-s-loyalty-status-and-rewards) through the client's profile.

> **What works in the FAQs:**
> - First person from the partner ("Can I set...", "Will clients be notified...")
> - Full context in every answer — no assumptions about having read the article
> - Cross-references to related articles (automated messages, client engagement, managing loyalty)
> - Cover genuine partner questions about edge cases (expiry rules, restoring points)
> - Concise answers that are still complete and actionable
