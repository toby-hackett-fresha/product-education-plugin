# Example Article: Set up payment policies

> **Why this is a good example:** This is a complex article with multiple workflows (deposits vs. capture card details), desktop/mobile variants, advanced options with sub-steps, cross-references to related articles, and a substantial FAQ section. It demonstrates how to handle branching paths, nested options, and thorough FAQ coverage.

---

## Title

Set up payment policies

> **What works:** Action-oriented ("Set up"), concise, descriptive. Sentence case. Doesn't repeat the category name ("Payments").

## Description

Secure bookings and reduce no-shows by collecting deposits or storing card details at the time of booking.

> **What works:** Under 92 characters. Summarizes the article's purpose clearly. Action-oriented.

## Intro

Learn how to secure bookings and reduce no-shows by setting up payment policies.

> **What works:** Starts with "Learn how to". Single sentence. Clear and concise.

## In this article (Index)

- How payment policies work
- Set up upfront deposits
- Set up capture card details

> **What works:** Index sentence is included because there are multiple ways to set up a payment policy (deposits vs. card capture). Each item links to its section. Action-led labels.

---

## How payment policies work

When you set up a [**payment policy in Fresha**](https://www.fresha.com/help-center/knowledge-base/payments/613-payment-policy-overview), it automatically applies to all appointments booked by default. Clients must meet the policy requirements to confirm their appointment with you.

You can also create custom payment rules for specific services, client groups, or appointment values. This flexibility allows you to decide when upfront payments are required and how they're applied.

> **What works:** "How it works" overview placed before steps. Explains the feature's purpose and behavior in plain language. Links to the related overview article. Helps the reader understand *why* before learning *how*.

---

## Set up upfront deposits

### Desktop

1. From the main menu on the left of your screen, go to [**Settings**](https://partners.fresha.com/setup).

2. Click on the **Payments** category to manage your payment policy.

3. Next to **Policy on all bookings**, select the **Edit** button.

4. In the **Payment policy** view, select **Require a deposit upfront**.

5. Under **Deposit amount**, choose to collect a **percentage** or **fixed amount** of the total appointment value, then enter the amount.

6. To protect against no-shows, tick the checkbox next to **Apply no-show fee**, then enter the percentage of the total appointment value you want to charge the client. This allows you to keep the money if the client doesn't show.

7. Tick the checkbox next to **Automatically cancel appointments for clients that did not pay a deposit** to cancel appointments booked by team members when the deposit isn't paid on time.

8. Use the first dropdown under **If not paid within** to choose how long clients have to pay the deposit (1-72 hours).

9. Use the dropdown on the right to choose whether the time counts **after booking the appointment** or **before the appointment start time**.

10. Under **Advanced options**, tick the checkboxes to tailor how your payment policy applies to specific services, clients, or appointment values. If no advanced options are selected, the policy will apply to all bookings by default:

    - **Customize per service** by clicking **Edit** to apply a custom deposit or no-show fee to specific services, then select **Apply** to save your changes. Once your payment policy is active, you can also manage whether a service requires a deposit and a custom deposit amount directly from the individual service's settings.

    - **Apply the policy to selected client groups**, such as new clients or those with previous no-shows or cancellations. To control whether an individual client is required to pay a deposit, update [**their profile settings**](https://www.fresha.com/help-center/knowledge-base/clients/207-update-client-details).

    - **Apply the policy to appointments over a set value** by entering the minimum amount.

11. Click on the **Save** button in the top right to update your payment policy.

### Mobile

1. From the main menu at the bottom of your screen, tap on **More** (grid icon) and open [**Settings**](https://partners.fresha.com/setup).

2. Under the **Workspace settings** list, tap on **Payments**, then **Payment policy.**

3. Next to **Policy on all bookings**, select the **Edit** button.

4. In the **Payment policy** view, select **Require a deposit upfront** from the drop-down menu.

5. Under **Deposit amount**, choose to collect a **percentage** or **fixed amount** of the total appointment value, then enter the amount.

6. To protect against no-shows, tick the checkbox next to **Apply no-show fee**, then enter the percentage of the total appointment value you want to charge the client. This allows you to keep the money if the client doesn't show.

7. Tick the checkbox next to **Automatically cancel appointments for clients that did not pay a deposit** to cancel appointments booked by team members when the deposit isn't paid on time.

8. Use the first dropdown under **If not paid within** to choose how long clients have to pay the deposit (1-72 hours).

9. Use the dropdown on the right to choose whether the time counts **after booking the appointment** or **before the appointment start time**.

10. Under **Advanced options**, tick the checkboxes to set the limits of your policy:

    - **Customize per service**: Tap **Edit** to apply a custom deposit or no-show fee to specific services, then tap **Apply** to save your changes.

    - **Apply the payment policy to selected client groups**, such as new clients or those with previous no-shows or cancellations. To control whether an individual client is required to pay a deposit, update [**their profile settings**](https://www.fresha.com/help-center/knowledge-base/clients/207-update-client-details).

    - **Apply the policy to appointments over a set value** by entering the minimum amount.

11. Tap on the **Save** button at the bottom to update your payment policy.

Once deposits are enabled, clients will need to pay a deposit to confirm their booking, securely saving their card to their wallet. At checkout, they can easily pay the remaining balance using [**their saved card**](https://www.fresha.com/help-center/knowledge-base/payments/108-collect-payments-using-client-stored-cards-2).

> **What works in the steps:**
> - First step includes full navigation ("From the main menu on the left of your screen, go to **Settings**") with a platform link.
> - All UI elements are **bolded** and capitalized as in-platform.
> - Present tense throughout ("Click", "Select", "Tick").
> - Each step has a directional phrase, action, and expected outcome.
> - Sub-options under Advanced options use bullet points, not numbers.
> - Desktop and mobile variants are separated.
> - Cross-references link to related articles (client profile settings, stored cards).
> - Closing paragraph explains what happens after completing the steps.

---

## Set up capture card details

### Desktop

1. From the main menu on the left of your screen, go to [**Settings**](https://partners.fresha.com/setup).

2. Next to **Policy on all bookings**, select the **Edit** button.

3. In the **Payment policy** view, select **Capture card details**.

4. Under **Charge when cancelling less than**, set the timeframe clients can cancel without being charged a cancellation fee.

5. To protect against late cancellations, tick the checkbox next to **Apply late cancellation fee.** Choose to collect a **percentage** or **fixed amount** of the total appointment value, then enter the amount.

6. To protect against no-shows, tick the checkbox next to **Apply no-show fee**, then enter the percentage of the total appointment value you want to charge the client, if they don't show.

7. Tick the checkbox next to **Automatically cancel appointments for clients that did not pay a deposit** to cancel appointments booked by team members when the deposit isn't paid within the set timeframe.

8. Use the dropdown on the left, under **If not paid within**, to choose how long clients have to pay the deposit (1-72 hours).

9. Use the dropdown on the right to choose whether the time counts **after booking the appointment** or **before the appointment start time**.

10. Under **Advanced options**, tick the checkboxes to set the limits of your policy:

    - **Customize per service**: Click **Edit** to apply a custom cancellation or no-show fee to specific services, then select **Apply** to save your changes.

    - **Apply the policy to specific client groups**, such as new clients or those with previous no-shows or cancellations. To control whether an individual client is required to confirm their appointment with a card, update [**their profile settings**](https://www.fresha.com/help-center/knowledge-base/clients/207-update-client-details).

    - **Apply the policy to appointments over a set value** by entering the minimum amount.

11. Click on the **Save** button in the top right to update your payment policy.

### Mobile

1. From the main menu at the bottom of your screen, tap on **More** (grid icon) and open [**Settings**](https://partners.fresha.com/setup).

2. Under the **Workspace settings** list, tap on **Payments**, then **Payment policy.**

3. Next to **Policy on all bookings**, select the **Edit** button.

4. In the **Payment policy** view, select **Capture card details**.

5. Under **Charge when cancelling less than**, set the timeframe clients can cancel without being charged a cancellation fee.

6. To protect against late cancellations, tick the checkbox next to **Apply late cancellation fee.** Choose to collect a **percentage** or **fixed amount** of the total appointment value, then enter the amount.

7. To protect against no-shows, tick the checkbox next to **Apply no-show fee**, then enter the percentage of the total appointment value you want to charge the client, if they don't show.

8. Tick the checkbox next to **Automatically cancel appointments for clients that did not pay a deposit** to cancel appointments booked by team members when the deposit isn't paid on time.

9. Use the first dropdown under **If not paid within** to choose how long clients have to pay the deposit (1-72 hours).

10. Use the dropdown on the right to choose whether the time counts **after booking the appointment** or **before the appointment start time**.

11. Under **Advanced options**, tick the checkboxes to set the limits of your policy:

    - **Customize per service**: Tap **Edit** to apply a custom cancellation or no-show fee to specific services, then select **Apply** to save your changes.

    - **Apply the policy to specific client groups**, such as new clients or those with previous no-shows or cancellations. To control whether an individual client is required to confirm their appointment with a card, update [**their profile settings**](https://www.fresha.com/help-center/knowledge-base/clients/207-update-client-details).

    - **Apply the policy to appointments over a set value** by entering the minimum amount.

12. Tap on the **Save** button at the bottom to update your payment policy.

Once card capture is enabled, clients will need to add their card details to confirm their booking, securely saving their card to their wallet. At checkout, they can easily pay their balance using [**their saved card**](https://www.fresha.com/help-center/knowledge-base/payments/108-collect-payments-using-client-stored-cards-2).

When a client confirms a booking using their card, a card capture fee applies for that appointment. If you complete checkout using Fresha Payments, the standard transaction fee plus VAT applies. If the appointment isn't checked out, or another payment method is used, the flat transaction fee plus VAT applies. The fee applies per appointment and helps protect your bookings.

---

## FAQs

### What fees apply when I take deposits or charge a client's saved card under payment policies?

Deposits and payments charged to a client's saved card are processed just like any other payment. This means that **standard payment processing fees apply**, based on the method used. For example, if a deposit is collected in-store, your regular **in-store payment fees** will apply. You can view the full list of rates on our [**pricing page**](https://www.fresha.com/pricing).

### How is the Marketplace new client fee calculated when clients pay a deposit upfront for their appointment?

The [**Marketplace new client fee**](https://www.fresha.com/help-center/knowledge-base/billing-and-fees/188-marketplace-new-client-fees) is calculated on the full appointment value, regardless of how the client pays. This means the fee is the same whether the client pays in full upfront, pays a deposit, or settles the balance at checkout.

### Why might clients be asked to complete two-step verification when booking online?

Clients may be asked to complete two-step verification (3D Secure) when booking online, as some banks require this extra step to keep payments secure. Clients may need to approve the payment in their banking app, by text message, or by phone call. Once verification is completed, the booking is confirmed.

### Will a new payment policy apply to existing appointments?

For existing appointments booked before the policy was updated, the new default payment policy does not apply automatically. You can **manually add a payment policy** to these bookings by clicking on **Actions** (three dots) within the appointment and selecting **Add payment policy**.

### How is payment collected if a client's card is declined when using capture card details?

If there are insufficient funds on the saved card, the payment will decline when charging a cancellation or no-show fee. When this happens, you'll have a few options:

- **Save as unpaid** so you can return later to retry the saved card or take payment another way.
- **Go back and edit the payment method**, then either reattempt the same card or collect the payment in cash.

This ensures you can still collect the payment, even if the initial card charge fails. You can choose to **set up deposits to collect a payment upfront** for future bookings, to reduce the risk of declined payments.

### What fees apply when I use Capture card details?

Standard Fresha payment fees apply when you confirm an appointment by capturing card details. A fixed-rate fee is charged for each appointment confirmed with a card, even if the appointment is not completed. If the appointment is checked out using Fresha payments, the percentage-based fee also applies. You can view all fees on [**our pricing page**](https://www.fresha.com/pricing).

### Can clients pay a deposit using iDeal?

Clients can pay a deposit using iDeal, with the payment taken securely at the time of booking. As iDeal card details are not stored, the card cannot be charged again for no-show or cancellation fees. Deposits can also be paid with supported cards such as Visa or Mastercard, which can be stored and later used to collect these fees.

### Can I set a fixed amount for no-show fees instead of a percentage?

Currently, only whole percentages can be entered when setting up payment policies with no-show fees. You can choose the nearest whole percentage.

### Will clients receive a notification if their appointment is cancelled for not paying the deposit on time?

Clients will receive an automated cancellation notification if their appointment is cancelled because the deposit was not paid within the required timeframe.

### Can I write my own cancellation and no-show policy?

Cancellation and no-show terms are created automatically from the payment policy you set up for your business, rather than being written manually. These terms are shown to clients in a standardised format during the booking process, helping keep information consistent and ensuring clients understand what applies before confirming an appointment.

### If I book an appointment in the calendar and don't require a deposit, will the appointment be auto-canceled?

If you manually book an appointment for a client, the default policy for that booking will be **No policy applied**, which disables auto-cancellation.

> **What works in the FAQs:**
> - Written in first person from the partner's perspective ("What fees apply when I...", "Can I set...")
> - Answers include full context — they don't assume the article was read
> - Include keywords naturally ("deposit", "no-show fee", "capture card details")
> - Link to relevant articles (pricing page, marketplace fees, client profile)
> - Cover genuine partner questions — no repetition of article steps
> - Answers are complete and actionable
