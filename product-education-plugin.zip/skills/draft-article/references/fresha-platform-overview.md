# Fresha Platform Overview

> **Purpose:** This reference provides contextual knowledge of the Fresha platform — what it is, what it does, and how its features are organized. When writing or reviewing Help Center articles, **always consult this document** to ensure accurate descriptions of features, correct understanding of how platform areas relate to each other, and appropriate context for the functionality being documented.

---

## What Fresha Is

Fresha is an all-in-one platform designed to help beauty and wellness businesses run their operations and grow. It combines scheduling, payments, client management, marketing, team management, and marketplace visibility into a single platform. Fresha positions itself as a leading booking platform in the beauty and wellness category and is used by a large number of businesses globally.

### Core Platform Pillars

1. **Scheduling and online booking** — so clients can book 24/7
2. **Payments and wallet/payouts** — process payments and manage cashflow
3. **Client management and retention tools** — build relationships and loyalty
4. **Marketing and automated messaging** — keep communications consistent and timely
5. **Team management** — shifts, permissions, and pay tools
6. **Marketplace visibility** — help new clients discover your business

---

## Platform Areas

### Marketplace and Online Profile

A major part of Fresha is helping clients discover and book with your business online:

- **Fresha Marketplace profile** — showcase your venue, services, photos, amenities, and description to help clients searching for services like yours find your business.
- **24/7 online booking** — clients can book from multiple channels, including the Fresha website/app, Google, social media, and your own website.
- **"Book now" buttons and links** — drive direct bookings from your own website and social media pages.
- **Third-party integrations** — support for Facebook/Instagram booking buttons, Reserve with Google, and direct booking links.

### Calendar, Scheduling, and Appointment Management

Fresha is built to reduce manual admin and keep your calendar running smoothly:

- Managing appointments and your day-to-day schedule.
- Letting clients self-book online, reducing time spent on calls and messages.
- Waitlist tools to capture excess demand when you're fully booked.

### Payments, Checkout, and Revenue Protection

Fresha supports taking payments and enforcing booking policies to protect your revenue:

- **Fresha Payments** — take payments in person or online.
- **Appointment protection options** — capture card details and take upfront payments to reduce no-shows.
- **Billing management** — view and download invoices, manage fees, and update your payment method.

### Business Wallet

Fresha includes a business wallet to help you track money movement and manage payouts:

- View wallet activity and understand how money flows through your account.
- Download statements for reconciliation.
- Set up automatic payouts to your bank account.
- Use your wallet balance to pay for your Fresha subscription and add-ons.
- Manage chargebacks if payment disputes occur.

### Clients, Retention, and Relationship Management

Fresha helps you build a client database and keep clients returning:

- **Client profiles** — maintain detailed client profiles and appointment history.
- **Client Loyalty** — set up loyalty programs with points, tiers, or both, and apply rewards at checkout.
- **Gift cards and memberships** — drive prepaid revenue and encourage repeat visits.

### Marketing and Automated Messaging

Fresha includes tools to keep your client communications consistent and timely:

- **Automated messages** — send reminders and notifications to clients automatically.
- **Messaging balance management** — manage your SMS and WhatsApp messaging credits.

### Team Management

For multi-staff businesses, Fresha supports a range of team management capabilities:

- Add team members and manage their access and permissions.
- Schedule and manage staff shifts.
- Set up and track commissions and wages.
- Run payroll with pay run tools.

### Inventory and Products

Fresha supports inventory and product management, allowing businesses to sell and track stock. This includes product catalogs, stock tracking, and an online store feature for retailing products.

### Reporting and Insights

Fresha offers reporting and insights tools to give you visibility into your business performance. Reports cover areas such as staff performance, rebooking rates, sales by service, and marketing effectiveness.

### Subscription Model

Access to Fresha is through a paid subscription plan. Plans are generally based on the number of bookable team members.

---

## Key Feature Summary

The features that most businesses rely on daily can be summarized across six key pillars:

| Pillar | What It Covers |
|--------|---------------|
| **Online booking and marketplace profile** | Generate demand and convert bookings through your Fresha Marketplace profile and 24/7 online booking. |
| **Calendar, scheduling, and waitlist** | Run your day smoothly with appointment management, self-booking, and waitlist tools. |
| **Payments and policies** | Reduce no-shows and secure revenue with deposits, card capture, and payment processing. |
| **Wallet, payouts, and statements** | Manage your cashflow with automatic payouts, wallet activity tracking, and downloadable statements. |
| **Clients, loyalty, and gift cards/memberships** | Improve retention and drive prepaid revenue with client profiles, loyalty programs, gift cards, and memberships. |
| **Team scheduling, permissions, and pay tools** | Manage staff shifts, control access levels, and handle commissions and wages. |

---

## Using This Reference

When writing articles, use this overview to:

- **Understand context** — know where a feature fits within the broader platform before writing about it.
- **Describe features accurately** — use the descriptions here as a baseline for how Fresha functionality should be characterized.
- **Cross-reference related areas** — identify related features that should be linked or mentioned in an article (e.g., an article about payments should reference appointment protection and wallet features where relevant).
- **Maintain consistency** — ensure all articles reflect a consistent understanding of what Fresha is and does.
