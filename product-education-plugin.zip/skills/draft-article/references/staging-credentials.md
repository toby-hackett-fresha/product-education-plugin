# Staging Environment Credentials

Use these credentials when navigating the Fresha staging environment to explore features for article writing.

## Staging URL

https://staging.fresha.com

## Login Credentials

**Email:** [ADD EMAIL]
**Password:** [ADD PASSWORD]

## Notes

- These credentials are for the staging environment only — never use them in production
- If the session expires or you are redirected to a login page mid-task, log in again using the same credentials
- The staging environment may differ slightly from production — always note any discrepancies and flag them in the article draft
