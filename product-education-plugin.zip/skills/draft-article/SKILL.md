---
name: draft-article
description: >
  Create a complete, publication-ready Fresha Help Center article — from research through writing,
  screenshot capture, and QA review — as a Word document (.docx). This is the end-to-end skill for
  new articles. Use this skill when the user wants to: write a new article, draft help content,
  create documentation for a feature, generate an article from a spec/release notes/feature description,
  capture screenshots from Figma for an article, or review/QA an article against content guidelines.
  Trigger on phrases like "draft an article", "write a new article", "create help content",
  "new help center article", "write up this feature", "document this feature", "capture screenshots",
  "screenshots from Figma", "review this article", "check article quality", "audit this content",
  or any request to produce a new Help Center article from scratch. Also trigger when the user provides
  a feature description, spec, or release notes and wants an article created from it.
---

# Draft a New Help Center Article

Create a complete, publication-ready Fresha Help Center article. This skill handles the full end-to-end workflow in four sequential phases:

1. **Gather inputs** — Collect sources (discovery docs, Figma, staging, specs)
2. **Gather context & capture screenshots** — Research the feature and capture visuals from Figma and/or staging
3. **Write the article** — Draft the article following all Fresha writing standards, output as a Word document
4. **QA review** — Audit the article against every content guideline, identify issues, apply fixes, and produce the final version

The article must follow every Fresha writing standard and be output as a Word document (.docx).

This skill supports **rich multi-source inputs** to produce the highest-quality articles. The best articles come from combining multiple sources — a PM discovery doc for context and user stories, Figma designs for visual flows, and the staging environment for verifying real UI behavior.

---

## Phase 1: Gather Inputs

Before writing anything, determine what sources are available. Use AskUserQuestion to ask the user which inputs they can provide for this article. Present these as a multi-select:

1. **Notion discovery doc** — A link to the PM's discovery document in Notion. This is the richest source — it contains the feature overview, user stories, design direction, and user feedback.
2. **Figma design file** — A Figma link with design flows and UI screens for the feature.
3. **Staging environment URL** — A URL to the feature in staging, so Claude can navigate and explore the real UI.
4. **Text description / spec / release notes** — A plain text description, pasted spec, or uploaded file (.docx, .pdf, .md) describing the feature.

At minimum, one input is required. The ideal combination is: **discovery doc + Figma + staging**.

If the user already provided one or more inputs in their initial message (e.g., a Notion link, a Figma URL, a staging URL, or a pasted description), acknowledge those and only ask about additional inputs they haven't mentioned yet.

---

## Phase 2: Gather Context & Capture Screenshots

Work through each available input to build a comprehensive understanding of the feature before writing.

### 2A. Notion Discovery Doc (if provided)

Fetch the Notion page using the Notion MCP tools (`notion-fetch`). The discovery doc follows a 5-section structure. Extract and record:

- **Feature overview** — What the feature does, who it's for, and why it's being built (Section 1: Overview → look for the dense overview paragraph and the "Opportunity" subsection)
- **User stories and acceptance criteria** — The specific workflows being built, organized by phase (Section 4: Proposition → 4.1 Recommended Features & User Stories). These map directly to the article's step-by-step workflows.
- **Design direction** — Core UX principles, key design decisions, blank states, mobile considerations (Section 4: Proposition → 4.2 Design Direction). This informs how to describe UI elements and navigation.
- **Partner pain points** — What partners have been saying about this problem area, representative quotes (Section 3: User Feedback). Use these to write informed, real-world FAQs.
- **Competitive context** — How competitors handle this feature (Section 2: Competitor Benchmark). Useful for understanding the feature's purpose but don't include competitor info in the article.
- **Open questions and risks** — Items that may affect how the article is written (Section 1 → Key Risks, Section 4.3 → Open Questions). Flag any that might mean the feature behavior isn't finalized.

If the discovery doc has subpages, fetch those too if they seem relevant to understanding the feature.

### 2B. Figma Design File (if provided)

Use the Figma MCP tools (`get_design_context`) to understand the design, then use browser automation to capture screenshots:

1. Call `get_design_context` with the Figma file key and node ID to get the design structure and reference code.
2. Open the Figma file in the browser using browser automation tools.
3. Identify frames showing:
   - Navigation paths (how users get to the feature)
   - Key UI states (forms, dialogs, settings panels, confirmation screens)
   - Step-by-step workflow sequences
   - Desktop vs. mobile variants
   - Edge cases or error states
4. Capture screenshots of each relevant frame.
5. Save screenshots with descriptive kebab-case filenames (e.g., `marketplace-boost-setup-panel.png`, `boost-budget-selector.png`).
6. Record which screenshot maps to which workflow step — this mapping is used in Phase 3 when placing screenshots in the article.

### 2C. Staging Environment (if provided)

Navigate the staging environment to verify real UI behavior and capture actual screenshots:

1. Open the staging URL in the browser.
2. **Log in using the credentials in `${CLAUDE_SKILL_ROOT}/references/staging-credentials.md`.** Read that file first, then use browser automation to enter the credentials and complete login. If a staging URL was provided by the user, navigate to that URL; otherwise use the default staging URL from the credentials file.
3. Once logged in, navigate to the feature being documented:
   - Follow the navigation path from the discovery doc or Figma designs
   - Explore the primary workflow (happy path)
   - Check secondary workflows if applicable
   - Note the **exact UI labels, button names, menu paths, and terminology** — these are the ground truth
4. Capture screenshots at each key step — these are the most accurate visuals since they show the real product.
5. **Cross-reference with Figma** — If both Figma and staging are available, prefer staging screenshots for the article (they're more accurate) but use Figma for any screens that aren't yet in staging or that show flows more clearly.

**Critical:** The exact wording of UI elements in staging is the ground truth. Use these exact terms in the article — they override any discrepancies in the discovery doc or Figma designs.

### 2D. Text Description / Spec / Release Notes (if provided)

Read the provided text, uploaded file, or pasted content. Extract:
- Feature description and purpose
- Key workflows
- UI changes
- Any limitations or edge cases mentioned

---

## Phase 3: Write the Article

### Writing Standards (Apply to Every Article)

#### Tone & Voice
Write in a clear, professional, and supportive tone. Be concise — every word must earn its place. Stay positive and action-oriented, focusing on what users *can* do. Be conversational but informative. Use American English throughout (exception: "cancellation" keeps the British spelling). Use contractions where natural. Never use passive voice. Present tense throughout.

**Keep language plain and direct. Avoid:**
- "meaningful segments" → say "groups" or "specific groups of clients"
- "streamline your workflow" → describe the actual benefit
- "leverage" / "utilize" → use "use"
- "text field" for UI inputs → use the element's label name or rephrase
- Any phrase that sounds like marketing copy rather than support writing

**Platform scope:** Say "across your workspace" — never "across Fresha" when describing where something applies within the platform.

#### Article Structure
Every article follows this structure:

1. **Title** — Action-oriented, concise, descriptive. Sentence case.
2. **Description** — Maximum 92 characters including spaces. Summarizes what the reader will learn.
3. **Intro** — Starts with "Learn how to..." Maximum 2 sentences. Link the first mention of a feature to the platform landing page.
4. **Headers (H2)** — Action-led, short, sentence case. Each introduces a distinct task or section.
5. **Index sentence** — Include only when there are multiple ways to accomplish one thing. Format: "From [location], you can: [list of actions as hyperlinks to sections]."
6. **"How it works" overview** — Include for complex features only. Place before step-by-step instructions. **Keep it brief — maximum 2–3 sentences.** Explain what the feature does and where it surfaces. Do not over-explain.
7. **Steps** — Numbered steps. Rules:

   **Never write outcome sentences inside a step.** Lines like "The workspace settings page opens." or "The panel appears." do not belong inside numbered steps. These belong only in the end state paragraph after all steps.

   **Navigation shorthand rule:** The first section to use a particular starting point writes the full path. Every subsequent section starting from the same place uses a shorthand:
   - First use: "From the main menu on the left of your screen, go to **Clients**."
   - Subsequent sections: "From your clients list, ..." or "From your workspace settings, ..."

   **End state paragraph (required):** Every workflow section must end with a standalone paragraph after the final step describing what is now true. This is never inside a numbered step. Examples:
   - "Your new tag is added to your library and ready to assign to client profiles."
   - "The assigned tags appear on the client's profile and are immediately visible to your team."

   **Multiple-option actions pattern:** When clicking Actions leads to choices, use a numbered step for the navigation, then sub-bullets for each option. Do not use a prose intro paragraph — go straight to steps.
8. **Callouts** — Notes only (never tips). Maximum one per flow. Positive sentiment. Format: `> **Note:** [content]`
9. **FAQs** — Written in first person from the partner's perspective ("How do I...?", "Can I...?", "What happens if...?"). Answers include full context. Cover genuine edge-case questions, not things already covered in the article body. Include keywords and link to relevant articles. Good: "Can a client have more than one tag?", "Can clients see the tags?" Bad: re-explaining steps already in the article.

#### Step Rules
- First step always includes full navigation path (e.g., "From the main menu on the left, go to **Calendar**") and links to the platform landing page.
- Bold and capitalize UI elements exactly as they appear in-platform. **If staging was explored, use the exact labels observed in staging.**
- Number main steps; use bullet points for sub-options.
- Include actual screenshots (from staging or Figma captures) within steps where helpful — reference them by filename.
- Hyperlink to relevant articles when other features are mentioned.
- Happy path first; advanced steps in separate sections.
- No icon descriptors in parentheses on desktop — these are mobile-only (e.g., "(pencil icon)" is wrong on desktop)
- Desktop and mobile variants should be separated when applicable.

#### Style Rules
- "Click" not "Press" (desktop) / "Tap" not "Press" (mobile)
- "For example" not "e.g." in article body
- Full sentences, even for short instructions
- Examples relevant to beauty and wellness businesses
- No vague instructions — always give specific direction
- Include relevant search keywords
- **Never include pricing information** — no dollar amounts, subscription costs, per-unit rates, trial details. If pricing context is relevant, link to the pricing page or use generic language.

#### Formatting
- **Bold**: UI elements (buttons, tabs, feature names) — capitalize as in-platform
- *Italic*: Not used for emphasis in Fresha articles
- Hyperlinks: Link to related Help Center articles when referencing other features
- Screenshots: Place within steps at the point they're most helpful
- Numbered lists for sequential steps; bullet points for non-sequential options

### Required References

Before writing, read these files from `${CLAUDE_SKILL_ROOT}/references/`:

1. **`fresha-platform-overview.md`** — REQUIRED. Understand where the feature fits within the broader platform before writing about it.
2. **`glossary.md`** — REQUIRED. Use the exact official names for every UI component. This glossary defines desktop vs. mobile terminology patterns, correct verbs ("click" vs. "tap"), and formatting rules for UI elements.
3. **`writing-guide.md`** — The full writing guide. Refer to this for any rule not explicitly covered in this skill — it is the authoritative source for all Fresha article writing standards.
4. **`example-payment-policies.md`** — Study this complex multi-workflow example. Pay attention to the `> **What works:**` annotations.
5. **`example-loyalty-points.md`** — Study this repeating sub-workflow example. Pay attention to the pattern consistency.

### Writing Process

1. **Load references.** Read the four files listed above. The glossary and platform overview are critical — never skip them.

2. **Draft the article.** Use the synthesized context from Phase 2:
   - Map discovery doc user stories to numbered step sequences
   - Use design direction to inform how UI elements are described
   - Use staging-verified UI labels as the ground truth for all element names
   - Apply the full writing standards above
   - Structure every section precisely: title, description, intro, headers, steps, callouts, FAQs

3. **Place screenshots.** Insert captured screenshots (from staging or Figma) at the appropriate points in the workflow:
   - If real screenshots were captured: `[Screenshot: filename.png — description of what it shows]`
   - If no screenshots were captured for a step: `[Screenshot: description of what to capture]`

4. **Write FAQs.** FAQs should cover the questions a partner would naturally ask when trying to use this feature. Draw from multiple sources to inform them:
   - Common questions about how the feature works, eligibility, or limitations
   - Edge cases or exceptions raised in the discovery doc
   - Any partner pain points from the user feedback section — but use these as one signal among many, not the sole source. User feedback may reflect old pain with the pre-existing experience; the article is documenting what's new.
   - Design decisions or "why does it work this way" questions that partners are likely to have
   Write FAQs in first person from the partner's perspective ("How do I...?", "Can I...?", "What happens if...?"). Answers should include full context and link to related articles where relevant.

5. **Generate the Word document.** Read the docx skill and use it to create a properly formatted .docx file with:
   - Heading 1 for the article title
   - The description clearly labeled below the title
   - Heading 2 for each section
   - Numbered lists for steps
   - Bullet points for sub-options
   - Bold text for all UI elements
   - Embedded screenshots where captured, or placeholders where not
   - FAQ section at the end

6. **Save the file** to the user's workspace folder with a descriptive kebab-case filename based on the article title (e.g., `set-up-online-booking.docx`).

---

## Phase 4: QA Review

After the article is drafted and saved, run a comprehensive quality audit against the full Fresha content guidelines. This phase catches issues before the article reaches a human reviewer.

### QA References

Before reviewing, read these files from `${CLAUDE_SKILL_ROOT}/references/` (if not already loaded from Phase 3):

1. **`checklist.md`** — REQUIRED. The definitive checklist to evaluate against. Every item must be assessed.
2. **`glossary.md`** — REQUIRED. Verify all UI component names match official terminology. Check desktop vs. mobile patterns.
3. **`writing-guide.md`** — The full exhaustive writing guide for detailed rule references.

### QA Process

1. **Run the full checklist.** Evaluate the article against every item in `checklist.md`. For each item, determine:
   - **Pass** — the article meets this criterion
   - **Fail** — the article violates this criterion (explain specifically how)
   - **N/A** — the criterion doesn't apply to this article (explain why)

2. **Identify specific issues.** For every failed checklist item, record:
   - The exact text or section that has the issue
   - What's wrong (referencing the specific guideline)
   - A concrete fix

3. **Check for additional quality issues** beyond the checklist:
   - Inconsistent terminology within the article
   - Missing navigation context in steps
   - UI elements not bolded or inconsistently capitalized
   - **UI component names that don't match the glossary** (e.g., "sidebar" instead of "main menu", "dropdown menu" instead of "dropdown", missing "(three dots)" on mobile Actions)
   - **Incorrect desktop/mobile terminology** (e.g., "click" on mobile, "tap" on desktop, wrong Save button location)
   - Passive voice instances
   - Vague instructions lacking specific direction
   - Missing screenshot opportunities
   - Missing cross-reference opportunities
   - **Any pricing information** — these must never appear in articles

4. **Apply fixes automatically.** For every issue found, fix it directly in the article. Re-generate the Word document with corrections applied. Save the corrected version, replacing the original file.

5. **Present the QA summary to the user.** After fixing, provide a brief summary:
   - Total checklist items assessed and how many passed / failed / N/A
   - The issues that were found and fixed (grouped by category: Structure, Steps, Tone, Style, UI Terminology, Callouts & FAQs, Pricing, General)
   - Any items that couldn't be auto-fixed and need manual attention (e.g., screenshots still needed, cross-reference links to verify, feature behavior to confirm)

---

## Input Quality Guide

| Inputs Available | Article Quality | What You Get |
|---|---|---|
| Text description only | Baseline | Structurally correct article, but may need manual verification of UI labels, navigation paths, and screenshots |
| Discovery doc | Good | Accurate feature context, informed FAQs from real user feedback, correct user stories mapped to steps |
| Discovery doc + Figma | Better | All of the above, plus captured screenshots and verified UI flows from designs |
| Discovery doc + Figma + Staging | Best | Ground-truth UI labels, real screenshots, verified navigation paths, highest accuracy |
