# Product Education

Help Center article creation, review, and management for the Fresha product content team.

## Overview

This plugin equips Claude with the Fresha Help Center writing standards, enabling it to draft, update, and review articles that follow your team's tone, structure, and formatting conventions. All articles are output as Word documents (.docx).

## Multi-Source Inputs

The **draft-article** and **update-article** skills support rich, multi-source inputs for the highest-quality output. You can provide any combination of:

| Input | What it provides |
|-------|-----------------|
| **Notion discovery doc** | Feature context, user stories, design direction, user feedback for FAQs |
| **Figma design file** | UI flows, screenshots, desktop/mobile variants |
| **Staging environment URL** | Ground-truth UI labels, real screenshots, verified navigation paths |
| **Text description / spec** | Feature description, workflows, change details |

The ideal combination is **discovery doc + Figma + staging** — this produces the most accurate articles with real screenshots and verified UI terminology.

## Skills

| Skill | Description |
|-------|-------------|
| `draft-article` | Draft a new Help Center article from a discovery doc, Figma designs, staging environment, or text description |
| `update-article` | Revise an existing article based on product changes, with optional discovery doc, Figma, and staging inputs |
| `review-article` | Audit an article against the full content guidelines checklist |
| `capture-screenshots` | Open a Figma file in the browser and capture relevant frame screenshots |

## Usage

### Draft a new article (with rich inputs)
> "Draft an article for Marketplace Boost — here's the discovery doc: [Notion link], Figma designs: [Figma link], and staging is at [staging URL]"

### Draft a new article (simple)
> "Draft an article about the new No-show protection feature that lets salon owners charge a fee when clients don't show up"

### Update an existing article
> "Update this article — the booking widget now supports group bookings" (attach the .docx, optionally provide Figma/staging links)

### Review an article
> "Review this article against the content guidelines" (attach the .docx)

### Capture screenshots from Figma
> "Capture screenshots from this Figma file for the article: https://www.figma.com/file/abc123/No-Show-Protection"

## Shared References

All skills draw from a common set of reference documents:

- **fresha-platform-overview.md** — Comprehensive overview of the Fresha platform and its features
- **writing-guide.md** — Full article writing guide with all rules, examples, and formatting standards
- **checklist.md** — Quick-reference checklist for reviewing articles against all standards
- **glossary.md** — Official UI component names and terminology
- **example-payment-policies.md** — Annotated example: complex multi-workflow article
- **example-loyalty-points.md** — Annotated example: repeating sub-workflow patterns

## Setup

This plugin works out of the box with Claude's built-in tools. For the richest experience:

- **Notion MCP** — Connect Notion to allow Claude to fetch discovery docs directly
- **Figma MCP** — Connect Figma to allow Claude to read design context and structure
- **Browser automation** — Used automatically for Figma screenshot capture and staging environment exploration
